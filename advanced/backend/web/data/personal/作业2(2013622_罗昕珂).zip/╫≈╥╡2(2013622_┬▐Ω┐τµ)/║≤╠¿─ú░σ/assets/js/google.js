if($("a[href='"+ window.location.pathname +"']").length !== 0){
    $("a[href='"+ window.location.pathname +"']").addClass('active');
} else {
    $(".g-top-menu a").click(function(e){
        $(".g-top-menu a").removeClass("active");
        $(this).addClass("active");
    })
    $(".g-left-menu a").click(function(e){
        console.info(e);
        $(".g-left-menu a").removeClass("active");
        $(this).addClass("active");
    })
    $(".g-arrow span").click(function(e){
        if($(".g-left-nav").hasClass("active")){
            $(".g-left-nav").removeClass("active");
            $(".g-arrow span").removeClass("glyphicon glyphicon-menu-left");
            $(".g-arrow span").addClass("glyphicon glyphicon-menu-right");
            $(".g-content").css("left", "60px");
        }else{
            $(".g-left-nav").addClass("active");
            $(".g-arrow span").removeClass("glyphicon glyphicon-menu-right");
            $(".g-arrow span").addClass("glyphicon glyphicon-menu-left");
            $(".g-content").css("left", "260px");
        }
    })
}